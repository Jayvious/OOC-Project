import java.util.Scanner;

public class Scanner_catch_take2 {

	public static void main(String[] args) {
		int enteredNumber = 0;
		Scanner myScanner = new Scanner(System.in);
		boolean numberError1 = false;
		String enteredString1 = "";

	do {
		try {
			System.out.print("Please enter an integer: ");
			enteredString1 = myScanner.next();  //Read into a string
			enteredNumber = Integer.parseInt(enteredString1.trim());  //then cast as a integer
			numberError1 = false;  //if we haven't bailed out, then the number must be valid.
		} catch(Exception e) {
			System.out.println("Your entry: \"" + enteredString1 + "\" is invalid...Please try again");
			numberError1 = true;  //Uh-Oh...We have a problem.
		}
	
	} while (numberError == true );  //Keep asking the user until the correct number is entered.

		
		System.out.println("\nThat was a valid Number.");
		System.out.println("You entered " + enteredNumber + "!");


	}
}	


