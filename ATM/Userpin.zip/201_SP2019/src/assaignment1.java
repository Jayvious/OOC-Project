
public class assaignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	
		int STOMACH_CAPACITY = 50;
		int sto_content = 0;
		while ( sto_content < STOMACH_CAPACITY ) {
			 //i'm still hungry....take a bite.
			 System.out.print(" Taking a bite...");
			 sto_content = sto_content +1;
			 //same as sto_content++
			 System.out.println("Content is " + sto_content);
		

		

	}

}
