
public class hw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 int NUMBER_CAPACITY = 50;
		 int sto_content = 1;
		
		 while ( sto_content < NUMBER_CAPACITY ) {
			System.out.println();
			sto_content = sto_content +1;
			 //same as sto_content++
			 System.out.println( + sto_content);
			 
			
			
			
		}
		    
		
		
		
		
		

	}

}
