
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
public class HW1 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to the Random Number Game!");

		 Random createrandom = new Random();
		 int randNum = (createrandom.nextInt(5) );
		 int enteredNumber = 0;
		 Scanner myScanner = new Scanner(System.in);
		 boolean numberError1 = false;
		 String enteredString1 = "";
		 int numberofattempts = 0;
		 boolean win = false;
		 
		 
			 

		while ( win == false) {
			do  { 
			try {
				System.out.print("Please guess the random number (integers only between 1 and 5: ");
				enteredString1 = myScanner.next();  //Read into a string
				enteredNumber = Integer.parseInt(enteredString1.trim());  //then cast as a integer
				numberError1 = false;  //if we haven't bailed out, then the number must be valid.
			} catch(Exception e) {
				System.out.println("Your entry: \"" + enteredString1 + "\" is invalid...Please try again");
				numberError1 = true;  //Uh-Oh...We have a problem.
			
			}
		
		} while (numberError1 == true );  //Keep asking the user until the correct number is entered.

		
			System.out.println("You entered " + enteredNumber + "!");
			numberofattempts ++;
			
			if ( enteredNumber == randNum) {
				win = true;
				
				
			}
				
				    
			else if (enteredNumber > randNum) 
			System.out.println("Too High! Try Again.");
			
			
		    else if ( enteredNumber < randNum)  
			  System.out.println("Too Low! Try Again.");
		    
				
			
		    
		    if  (enteredNumber == randNum){
			System.out.println("right! You win");
		    }
	
			System.out.println("it took you " + numberofattempts + " attempts.");
			
			
			Scanner t = new Scanner(System.in);
			
			System.out.println("Do you want to play again?");
			System.out.println("Enter 1 for yes and 2 for no");
			
			int x = t.nextInt();
			 if (x == 1) {
				 win = false;
				 System.out.println("Thank you for playing, Bye!");
			 } else
			 win = true;
			
			 
	
			
				
		
		  
			
			}
				
		 
		 	
	
	}
}
