import java.util.Scanner;
public class newstart {

	private static Object total;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] testScores = new int[10];
		
		testScores[0] = 100;
		testScores[1] = 85;
		testScores[2] = 60;
		testScores[3] = 72;
		
		
		int lengthofArray = testScores.length;
		int total = 0;
		System.out.println("Length is : " + lengthofArray);
		
		for (int i = 0; i < testScores.length; i++) {
			total = total + testScores[i];
			
		}
		System.out.println("Student sum :" + total);

	 }


  }

   
