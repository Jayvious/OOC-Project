
public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      System.out.println("Hello,");
      System.out.print("world");
      
      
      
      System.out.println();
      
      
      String a = "2b or ";
      String b = "-2b"; 
      
      
      String c = a + b;
      
      System.out.println(c);
      
      
      
      int x = 7;
      int y = 9;
      
      int z = x + y;
      
      System.out.println(z);
      System.out.println("The value of " + x + " and " + y + " is " + z);
      
      String doneString = "37";
      int doneNumber = 5 ;
      int myNum =Integer.parseInt(doneString);
      System.out.println(myNum);
      
      
      boolean isGonnaSnow = true;
	}
	
	
	
          	
	  

}
