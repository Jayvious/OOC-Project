import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
public class list {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	   ArrayList<String> students  = new ArrayList<String>();
	   
	   students.add("5");
	   students.add("Sue");
	   students.add(" Mike");
	   
	   int arraySize = students.size();
	   System.out.println("Size is :" + arraySize);
		
	   String name = students.get(1);
	   System.out.println("Name is :" + name);
	   
	   students.add("tom");
	   
	   arraySize = students.size();
	   System.out.println("Size is :" + arraySize);
	   
	   
	   for (int i = 0; i < students.size(); i++) {
		   System.out.println("Student #" + i + " is named : " + students.get(i));
		   
	   }
	    
	   Scanner keyboard = new Scanner(System.in);
	   

	   System.out.println("Gimme a name to delete :");
	    String nameToDel = keyboard.nextLine();
	   
	   for (int i = 0; i < students.size(); i++) {
		   if (nameToDel.compareTo(students.get(i)) == 0) {
			  students.remove(i);
			  System.out.println("we removed :" + nameToDel + "From index number" + i);
		   
		   System.out.println("Student #" + i + " is named : " + students.get(i));
	   
	   } 
	    
	    
	 }   
	   
	 
	    for (int i = 0; i <students.size(); i++) {
	    	System.out.println("Student # " + i + " is named ;" + students.get(i));
	    	
	    Random myRand = new Random();
	    for (int i1 = 0; i1 <99; i1++) {
	    	 int randNum = (myRand.nextInt(5) );
	 	    System.out.println(randNum);
	 	    
	    }
	
	  
	   
		    
	   }
	
	}
	

}
