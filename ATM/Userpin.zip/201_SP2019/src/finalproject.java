import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class finalproject {

	public static void main(String[] args) {

		BufferedReader reader = null;
		ArrayList <String> myFileLines = new ArrayList <String>();

		try {

			String sCurrentLine;

			reader = new BufferedReader(new FileReader("/Users/tyreekwilliams/Downloads/mary.txt"));
			
			

			while ((sCurrentLine = reader.readLine()) != null) {
				System.out.println(sCurrentLine);
				myFileLines.add(sCurrentLine);
				
			}

		} catch (IOException e) {
			e.printStackTrace();
			System.out.print(e.getMessage());
		} finally {
			try {

				if (reader != null)reader.close();
			} catch (IOException ex) {
				System.out.println(ex.getMessage());
				ex.printStackTrace();

			}
		}
		for (int i = myFileLines.size() - 1; i>= 0; i-- ) {
			String myLine = myFileLines.get(i);
			//System.out.println(myFilesLines.get(i);
			int spacePos = 0;
			String lineNum = "";
			for ( int c = 0; c <= myLine.length(); c++) {
				if ( (myLine.substring( c, c+1)).contentEquals(" ")) {
					//character must be a space
					//the line number is all characters from 0 to the position of the space 
					lineNum = myLine.substring(0, c);
					System.out.println(lineNum);
					break;
					
				}

			}
		}
		
	}
}
