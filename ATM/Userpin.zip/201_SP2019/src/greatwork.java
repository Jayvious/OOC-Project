
public class greatwork {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

			int first = 60;
			int second = 3;
			int total = 875;

			while (total < 875) {
			   total = first + second;
			   first = second;
			   second = total;
			System.out.println(total);
			
			}
			
			
			
		} 
		
		
		
		
		
		
		
		
		
		
		
	}


