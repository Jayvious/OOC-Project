
public class inclass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
			 
		 int END = 50;
		 int START = 0;
		
		 while ( START < END ) {
			System.out.println();
			START = START +1;
			 //same as START++
			 System.out.println( + START);
		 
			 
			 if(START % 2 == 0 && START % 5 ==0 ) {
				 System.out.println("BUBBLE GUM");
			 }
			 
			 else if (START %2 ==0) {
				 System.out.println("GUM");
			 }
			
			
			
		}
		    
		
		
		
	
			
			
		
		      
		

	}
	

}
