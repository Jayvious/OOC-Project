
import java.util.*;
import java.io.*;

public class Person {

	private String first_name;
	private String last_name;
	private int age;
	
	//Constructors
	public Person() {
		this.first_name = "Test";
		this.last_name = "Person";
		this.age = 18;
	}
	
	public Person(String first_name, String last_name, int age) {
		try {
			this.setFirstName(first_name);
			this.setLastName(last_name);
			this.setAge(age);
		} catch(Exception e) {
			this.first_name = "Test";
			this.last_name = "Person";
			this.age = 18;
		}
		
	}
	
	//first_name getter and setter functions
	public String getFirstName() {
		return this.first_name;
	}
	public void setFirstName(String first_name) throws Exception {
		if(first_name == null || first_name == "") {
			throw new Exception("first_name cannot be null or empty string");
		}
		this.first_name = first_name;
	}

	//last_name getter and setter functions
	public String getLastName() {
		return this.last_name;
	}
	public void setLastName(String last_name) throws Exception {
		if(last_name == null || last_name == "") {
			throw new Exception("last_name cannot be null or empty string");
		}
		this.last_name = last_name;
	}

	//age getter and setter functions
	public int getAge() {
		return this.age;
	}
	public void setAge(int age) throws Exception {
		if(age < 0) {
			throw new Exception("age cannot be less than zero");
		}
		this.age = age;
	}
	
	//toString function to display Person Object as a String
	public String toString() {
		String return_string = "";
		
		return_string += "First Name: " + this.first_name + "\n";
		return_string += "Last Name: " + this.last_name + "\n";
		return_string += "Age: " + this.age + "\n";
		
		return return_string;
	}
	
	/**
	 * 
	 * @param person_list - List of Person Objects to print to standard out
	 */
	public static void printPersonList(List<Person> person_list) {
		for(int i = 0; i < person_list.size(); i++) {
			System.out.println(person_list.get(i).toString());
		}
	}
	
	/**
	 * 
	 * @param filepath - File path to csv file that contains Person data to read
	 * @return - Person ArrayList containing csv person data
	 */
	public static ArrayList<Person> importFile(String filepath) {
		ArrayList<Person> person_list = new ArrayList<Person>();
		//Insert your code here...
		BufferedReader br= null
				try {
					br= new Buffered Reader ( new FileReader (filepath));
					String s = "";
					while ((s = br.readLine ()) ! =null) {
						String [] person= s.split(",");
						if (person.length > 0) {
							person p = new person(person{[0], person[1],integer.parseInt);
							person_list.add(p);
							}
						}
					}
				}
		
		return person_list;
	}
	
	/**
	 * 
	 * @param filepath - File path to write Person Object data to csv file
	 * @param person_list - Person Object ArrayList to write to file
	 */
	public static void exportFile(String filepath, ArrayList<Person> person_list) {
		//Insert your code here...
		try {
			FileWriter file = new FileWriter(filepath);
			int list = person_list.size();
			for(int i = 0; i< list; i++) {
				file.append(String.join("," , person_list.get(i).first_name()));
				file.append(String.join("," , person_list.get(i).last_name()));
				file.append(String.join("," , Integer.toString(person_list.get(i).getAge())));
				file.append("\n");
				
				
			}
			file.flush();
			file.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
}
