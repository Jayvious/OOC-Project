import java.util.*;

public class Asn4 {

	
	
	public static void main(String[] args) {		
		int[] test_array = { 3, 7, 1 };
		int n = 2;
		


		int result_sum = sumIntArray(test_array);
		int i;
		for (i = 0; i < test_array.length; i++) 
            result_sum+=  test_array[i]; 
		//System.out.println("sumIntArray result for " + stringifyArray(test_array) + " is " + result_sum);
		
		//Uncomment the below lines when you implemented "powerIntArray"
		
		


		double result_pow = powerIntArray(test_array, n);
		
	     
		System.out.println("powerIntArray result for n = " + n + " is " + stringifyArray(result_pow));
		


		//Uncomment the below lines when you implemented "powerSumIntArray"
		int result_pow_sum = powerSumIntArray(test_array, n);
	//	System.out.println("powerSumIntArray result for " + stringifyArray(test_array) + " n = " + n + " is " + result_pow_sum);
	}

	
	private static String stringifyArray(double result_pow) {
		// TODO Auto-generated method stub
		return null;
	}


	private static int powerSumIntArray(int[] test_array, int n) {
		// TODO Auto-generated method stub
		return 0;
	}


	private static double powerIntArray(int[] test_array, int n)
	{
		int i;
		double result_pow = 0;
		for (i = 0; i < test_array.length; i++)
			   result_pow =(Math.pow(test_array [i], n));
		    
		return result_pow;
		
	}


	private static int sumIntArray(int[] test_array) {
		// TODO Auto-generated method stub
		return 0;
	}


	//public static String stringifyArray(double result_pow) {
		
	//	String out_string = "{ ";
		
	//	for(int element : result_pow) {
		//	out_string += element + ", ";
		//}
		
		//out_string = out_string.substring(0, out_string.length()-2) + " }";
		
	//	return out_string;
	// }
}
