package Cars;

public class TeslaModel3 extends Car {
	
	private float acceleration_factor;
	private int weight;
	private String model;
	private int current_speed;
	private boolean super_mode;


	public TeslaModel3() {
		super();
		this.setAcceleration_factor(.12f);
		this.setWeight(275);
		this.setModel("Tesla Model 3");
	}

	
	
		
		
	
	public void enableSuperMode() {
			setAcceleration_factor((float) .2);
					
		}
	public void pressGasPedal() {
	
	
		setSuper_mode(false);
		super.pressGasPedal();
		
		
		if(this.current_speed > 65) {
			this.current_speed = 65;
		}
	}






	public float getAcceleration_factor() {
		return acceleration_factor;
	}






	public void setAcceleration_factor(float acceleration_factor) {
		this.acceleration_factor = acceleration_factor;
	}






	public int getWeight() {
		return weight;
	}






	public void setWeight(int weight) {
		this.weight = weight;
	}






	public String getModel() {
		return model;
	}






	public void setModel(String model) {
		this.model = model;
	}






	public boolean isSuper_mode() {
		return super_mode;
	}






	public void setSuper_mode(boolean super_mode) {
		this.super_mode = super_mode;
	}
	}

