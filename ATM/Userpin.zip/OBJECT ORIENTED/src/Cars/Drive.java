package Cars;

public interface Drive {

	
	public abstract void pressGasPedal();
	
	public abstract void pressBrakePedal();
	
}
