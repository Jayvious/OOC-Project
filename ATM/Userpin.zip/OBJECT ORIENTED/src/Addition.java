
public class Addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		float arg1 = Float.parseFloat(args[0]);
		float arg2 = Float.parseFloat(args[1]);
		float total= arg1 + arg2; 
		System.out.println( + total); 
 
	}
        
}
