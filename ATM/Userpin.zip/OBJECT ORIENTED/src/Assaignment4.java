
public class Assaignment4 {
	     public static void main(String[] args) {         
	          int[] test_array = { 6, 7, 9 };
	          
	          int n = 2;
	       
          
	          int result_sum = sumIntArray(test_array);
	          int i;
	          for (i = 0; i < test_array.length; i++) 
	              result_sum+=  test_array[i]; 
	          System.out.println("sumIntArray result for " + stringifyArray(test_array) + " is " + result_sum);
	         

	          
	          int[] result_pow = powerIntArray(test_array, n);
	          
	          
	        	  
	          System.out.println("powerIntArray result for n = " + n + " is " + stringifyArray(result_pow));
	         

	          
	          int result_pow_sum = powerSumIntArray(test_array, n);
	          result_pow_sum+= test_array[i];
	          for (i = 0; i < test_array.length; i++)
	          System.out.println("powerSumIntArray result for " + stringifyArray(test_array) + " n = " + n + " is " + result_pow_sum);
			return result_pow_sum;
	     }
	     

		private static int powerSumIntArray(int[] test_array, int n) {
			// TODO Auto-generated method stub
			return 0;
		}

		
		
		private static int[] powerIntArray(int[] test_array, int n) {
			
			return 0;
		}

		private static String stringifyArray(int[] test_array) {
			// TODO Auto-generated method stub
			return null;
		}

		private static int sumIntArray(int[] test_array) {
			// TODO Auto-generated method stub
			return 0;
		}
	     

		}


	 



	
	
	
	
	 
	


