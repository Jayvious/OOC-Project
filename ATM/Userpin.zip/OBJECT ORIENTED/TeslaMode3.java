package Cars;

public class TeslaModel3 extends Car {
	
	public TeslaModel3() {
		super();
		this.acceleration_factor = .12f;
		this.weight = 275;
		this.model = "Tesla Model 3";
	}

	
	@Override
	public void pressGasPedal() {
		
	
	public void enableSuperMode() {
			if super_mode=true ;
					acceleration_factor =.2;
					
		}
	public void pressGasPedal() {
	
		super_mode = false;
		
		
		super.pressGasPedal();
		
		
		if(this.current_speed > 65) {
			this.current_speed = 65;
		}
	}
	}
}
