class Holiday {

       private String name;

       private int day;

       private String month;

       

       public Holiday(String name, int day, String month)

       {

              this.name = name;

              this.day = day;

              this.month = month;

       }

      

       public String getName() {

              return name;

       }

       public void setName(String name) {

              this.name = name;

       }

       public int getDay() {

              return day;

       }

       public void setDay(int day) {

              this.day = day;

       }

       public String getMonth() {

              return month;

       }

       public void setMonth(String month) {

              this.month = month;

       }


       public static double avDatewhich(Holiday[] Array)

       {

              double sum = 0;

              for(int i=0;i<Array.length;i++)

              {

                     sum = sum + Array[i].getDay();

              }

              return sum/Array.length;

       }

      

    

       public static boolean inSameMonth(Holiday h1, Holiday h2)

       {

              if(h1.getMonth().equalsIgnoreCase(h2.getMonth()))

                     return true;

              else

                     return false;

       
       
       }

      

       public static void main(String[] args)

       {
    	   
       }
}