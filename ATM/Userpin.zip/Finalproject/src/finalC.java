
public class finalC {

	
	
	
	public static void main(String[] args) {
		  // TODO Auto-generated method stub

		  int a =1; 
		  int b=1; 
		  int c = 0;
		  
		  System.out.println(a); 
		  System.out.println(b); 
		  while ( c < 500) {  
		   c=(a+b); 
		   a=b; 
		   b=c;
		   System.out.println(c);
		  } 
		 
	
	}

	   

}
