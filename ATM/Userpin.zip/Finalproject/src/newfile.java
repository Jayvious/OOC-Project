
import java.util.*;


public class newfile
{
   
    public static void main(String[] args)
    {
      
        int numbPlayers,rounds=1;
        int playersArray[]=new int[10];
        int guessArray[] = new int[10];
        int index[] = new int[10];
        int guessNumber[]=new int[10];
        boolean b=true;
        char ss;
        Scanner s= new Scanner(System.in);
       
       
        do
        {
         
            Scanner sc= new Scanner(System.in);
               
            
            System.out.print("\nEnter number of players: ");
            Scanner t = new Scanner(System.in);
            int numPlayers = 0;
			Game g = new Game(numPlayers);
            for (int i = 0; i < numPlayers; i++) {
    			System.out.print("Player " + (i+1) + " enter name: ");
    			String name = t.nextLine();

    			Player p = g.getPlayer(i);
    			p.setName(name);
    		}
       
           
            numPlayers=sc.nextInt();
   
          
            if(!(numPlayers>0))
       
             
                System.out.println("Invalid number of players");
       
       
            
            for(int x=0;x<numPlayers;x++)
            {
               
                Random r=new Random();
               
              
                playersArray[x]=r.nextInt(100);
                index[x]=0;
                guessNumber[x]=0;
            }
           
           
            while(b)
            {
               
                System.out.println("\nRound "+rounds);
               
               
                for(int x=0;x<numPlayers;x++)
                {
                                 
                    if(index[x]==0)
                    {
                      
                        System.out.print("Player "+(x+1)+" guess your number:");
                       
                      
                        guessArray[x]=sc.nextInt();
                       
                       
                        index[x]=play(guessArray[x],playersArray[x]);
                       
                       
                        guessNumber[x]++;
                    }
                   
                   
                    b=false;
                }
               
               
                rounds++;
               
               
                for(int x=0;x<numPlayers;x++)
                {
                   
                    if(index[x]!=1)
                       
                        b=true;
                }
            }
           
            
            int playerrank[]=new int[10];
            int noOfguesses[]=new int[10];
           
            
            for(int x=0;x<numPlayers;x++)
            {
               
                noOfguesses[x]=guessNumber[x];
            }
           
            
            for(int x=0;x<numPlayers;x++)
            {
               
                for(int k=x;k<numPlayers;k++)
                {
                   
                   
                    if(noOfguesses[x]>noOfguesses[k])
                    {
                       
                        int temp=noOfguesses[x];
                        noOfguesses[x]=noOfguesses[k];
                        noOfguesses[k]=temp;
                    }
                }
            }
           
           
            for(int x=0;x<numPlayers;x++)
            {
               
                for(int k=0;k<numPlayers;k++)
                {
                   
                    if(guessNumber[x]==noOfguesses[k])
                       
                        
                        playerrank[x]=k+1;
                }   
            }
                   
           
            System.out.println("Player\tNumber of guesses\tRank");
           
           
            for(int x=0;x<numPlayers;x++)
            {
              
                System.out.println((x+1)+"\t"+ guessNumber[x]+"\t\t\t"+playerrank[x]);
            }
           
           
            System.out.println("Play again? y for yes and n for no");
        }
       
       
        while(s.next().equals("y"));
    }
   
   
    public static int play(int guessArray,int noOfguesses)
    {
        
        if(guessArray==noOfguesses)
        {
           
            System.out.println("Correct");
           
           
            return 1;
        }
       
       
        else
        {
          
            if(guessArray>noOfguesses)
            {
                System.out.println("Too High");
               
                
                return 0;
            }
           
            else
            {
               
                System.out.println("Too Low");
               
                
                return 0;
            }
        }
    }
}