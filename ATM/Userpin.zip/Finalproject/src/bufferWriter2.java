import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class bufferWriter2 {
	public static void main(String[] args) {

		BufferedReader reader = null;
		ArrayList <String> myFileLines = new ArrayList <String>();

		try {

			String sCurrentLine;

			reader = new BufferedReader(new FileReader("/Users/tyreekwilliams/Downloads/mary.txt"));

			while ((sCurrentLine = reader.readLine()) != null) {
				System.out.println(sCurrentLine);
				myFileLines.add(sCurrentLine);
			}

		} catch (IOException e) {
			e.printStackTrace();
			System.out.print(e.getMessage());
		} finally {
			try {

				if (reader != null) {
					reader.close();
				}
			} catch (IOException ex) {
				System.out.println(ex.getMessage());
				ex.printStackTrace();

			}
		}
		String lineContent = "";
		int lineLength = 0;
		String lineNumber = "";
		for (int i = myFileLines.size() - 1 ; i >=0 ; i--) {
			lineLength = myFileLines.get(i).length();
			lineContent = myFileLines.get(i);
			//System.out.println(myFileLines.get(i));
			for ( int c = 0; c <= myFileLines.get(i).length() -1 ; c++ ) {
				if (lineContent.substring(c, c+1).contentEquals(" ")) {
					lineNumber = lineContent.substring(0, c);
					System.out.println(lineNumber);
					break;
				}
			}

		}


		///NOW WE WRITE


		try {

			String content = "This is the content to write into file";

			File outfile = new File("/Users/tyreekwilliams/Downloads/outfile.txt");

			// if file doesnt exists, then create it
			if (!outfile.exists()) {
				outfile.createNewFile();
			}

			FileWriter fw = new FileWriter(outfile.getAbsoluteFile());  //Open the file for writing
			BufferedWriter bw = new BufferedWriter(fw);

			//------------------------
			bw.write("");

			for (int i = myFileLines.size() - 1 ; i >=0 ; i--) {
				lineLength = myFileLines.get(i).length();
				lineContent = myFileLines.get(i);
				//System.out.println(myFileLines.get(i));
				for ( int c = 0; c <= myFileLines.get(i).length() -1 ; c++ ) {
					if (lineContent.substring(c, c+1).contentEquals(" ")) {
						lineNumber = lineContent.substring(0, c);
						System.out.println(lineNumber);
						bw.append(lineContent);
						bw.newLine();
						break;
					}
				}
			}
			//------------------

			bw.flush();   //Always a good habit to flush when you are through
			bw.close();

			System.out.println("Done");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}