import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class finalProject {
	

	
	public static void main(String[] args) {
		
	
		  {
			  int counter = 1;
			 
			
				String guess1Parsed ="";
				 
				String appendNewRound = "Round " + counter; 
				
				try {

					
					File outfile = new 
							File("/Users/tyreekwilliams/Downloads/MP_RNG_Round_" + counter + ".txt");


					if (!outfile.exists()) {
						outfile.createNewFile();
					}

					FileWriter fw = new FileWriter(outfile.getAbsoluteFile());   
					BufferedWriter bw = new BufferedWriter(fw);
					

					bw.write(appendNewRound);
					bw.newLine(); 
				

					

					for (int i=0; i < counter; i++) { 
						int guess1 = counter;
						guess1Parsed = Integer.toString(guess1);  
						bw.write(guess1Parsed + " ");   //Write it to the new file
					
					}
					bw.newLine();

					bw.flush();   //Always a good habit to flush when you are through
					bw.close();
					System.out.println("Log created");
				} catch (IOException e) {
					e.printStackTrace();
			  }
				counter ++;
			}

				

				System.out.println("Welcome to the Random Number Game!");

				String choice = "Yes";
				Scanner read = new Scanner(System.in);

				while (choice.equals("Yes")) {
					play(); 
					System.out.print("Do you want to play again (Yes/No)? ");
					choice = read.next();
					while(!(choice.equals("Yes") || choice.equals("No"))) {
						System.out.println("invalid response.. only Yes/No");
						System.out.print("Do you want to play again (Yes/No)? ");
						choice = read.next();
						System.out.println("Thanks for playing, bye!");

					}
				}

			}
	public static void play() {

		String NP = "How many players are playing the game? : ";
		int numPlayers = getPositiveInteger(NP);
		Game g = new Game(numPlayers);
		Scanner t = new Scanner(System.in);

		for (int i = 0; i < numPlayers; i++) {
			System.out.print("Player " + (i+1) + " enter name: ");
			String name = t.nextLine();

			Player p = g.getPlayer(i);
			p.setName(name);
		}
	

		g.selectRandNumbers();

		System.out.println(" random numbers for each of you have been created ");

		while (!g.hasEnded()) {
			System.out.println();

			for (int i = 0; i < numPlayers; i++) {
				Player p = g.getPlayer(i);

				if (!p.getGuessedCorrectly()) {
					NP = p.getName() + ", please guess a number between 1 and 100: ";
					int posInt = getPositiveInteger(NP);


					if (posInt == p.getNumberToGuess()) {
						p.setGuessedCorrectly(true);
						g.addWinner(p);
						System.out.println("right! You win");
					}
					else if (posInt < p.getNumberToGuess()) {
						p.addGuess(posInt);
						System.out.println("Too Low! Try Again.");
					}
					else {
						p.addGuess(posInt);
						System.out.println("Too High! Try Again.");
					}
				}
			}
		}

		displayResults(g);
	}
	public static void displayResults(Game g) {

		System.out.println("results");
		System.out.println("PLACE     NAME   NUMBER OF ATTEMPTS    WRONG ATTEMPTS");
		for (int i = 0; i < g.getNumPlayers(); i++) {
			System.out.print(String.format("%2d", i+1) + " ");
			Player p = g.getWinner(i);
			p.displayResult();
			System.out.println();
		}
	}
	
	public static int getPositiveInteger(String NP) {

		int posInt;
		Scanner t = new Scanner(System.in);

		System.out.print(NP);

		while (!t.hasNextInt()) {
			String input = t.next();
			System.out.println("error “" + input + "” is not a valid integer.. try again");
			System.out.print(NP);
		}
		posInt = t.nextInt();

		while (posInt < 0) {
			System.out.println("error “" + posInt + "” is not a valid positive integer.. try again");
			System.out.print(NP);
			while (!t.hasNextInt()) {
				String input = t.next();
				System.out.println("error “" + input + "” is not a valid integer.. try again");
				System.out.print(NP);
			}
			posInt = t.nextInt();
		}

		return posInt;
	}


} class Game {

	Player[] players;	
	int numPlayers;		
	int PlayersWhoWin;	
	Player[] winners;	

	public Game() {
		players = null;
	}
	public Player getPlayer(int index) {
		return players[index];
	}
	public boolean hasEnded() {
		if (numPlayers == PlayersWhoWin)
			return true;
		return false;
	}
	public void addWinner(Player player) {

		winners[PlayersWhoWin] = player;
		PlayersWhoWin += 1;
	}
	public  int getNumPlayers() {
		return numPlayers;
	} 
	public Game(int numPlayers) {
		this.numPlayers = numPlayers;	
		players = new Player[numPlayers];
		for (int i = 0; i < numPlayers; i++) {
			players[i] = new Player();
		}
		PlayersWhoWin = 0;
		winners = new Player[numPlayers];
	}
	public Player getWinner(int index) {
		return winners[index];
	}

	public void selectRandNumbers() {

		Random rand = new Random();

		for (int i = 0; i < numPlayers; i++) {
			int randInt = rand.nextInt(100) + 1;
			players[i].setNumberToGuess(randInt);
		}
	}

}class Player {

	private static final int[] NumberToGuess = null;
	private String name;				
	private int numberToGuess;			
	private boolean guessedCorrectly;	
	private int numberOfGuesses;		

	private int [] allGuesses;			

	public Player() {
		name = "";
		numberToGuess = 1;
		guessedCorrectly = false;
		numberOfGuesses = 0;
		allGuesses = new int[100];
	}

	public Player(String name) {
		this.name = name;
		this.numberToGuess = 1;
		this.guessedCorrectly = false;
		numberOfGuesses = 0;
		allGuesses = new int[100];
	}

	public void displayResult() {
		System.out.print(String.format("%20s", name) + String.format("%12d", numberOfGuesses) + " Guesses    ");
		for (int i = 0; i < numberOfGuesses - 1; i++) {
			System.out.print(allGuesses[i] + ", ");
		}
		System.out.print(allGuesses[numberOfGuesses - 1]);
	}
	public void setNumberOfGuesses(int numberOfGuesses) {
		this.numberOfGuesses = numberOfGuesses;
	}
	public int getNumberToGuess() {
		return numberToGuess;
	}
	public String getName() {
		return name;
	}
	public int[] getAllGuesses() {
		return allGuesses;
	}
	public int getNumberOfGuesses() {
		return numberOfGuesses;
	}
	public void addGuess(int guess) {
		allGuesses[numberOfGuesses] = guess;
		numberOfGuesses += 1 ;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean getGuessedCorrectly() {
		return guessedCorrectly;
	}
	public void setGuessedCorrectly(boolean guessedCorrectly) {
		this.guessedCorrectly = guessedCorrectly;
	}
	public void increaseNumGuesses() {
		numberOfGuesses += 1;
	}
	public void setNumberToGuess(int numberToGuess) {
		this.numberToGuess = numberToGuess;
	
}
}